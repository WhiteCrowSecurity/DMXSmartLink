DMXSmartLink Stream Deck for Windows
====================================
1. Unzip this folder anywhere (keep hidapi.dll next to the exe).
2. Quit the Elgato Stream Deck app if it is running (it holds the device).
3. Plug your Stream Deck or YoloDeck into this PC.
4. Double-click DMXSmartLink-StreamDeck.exe.
   The window finds your DMXSmartLink hub on the network and connects by itself.
   If it finds more than one hub, pick one from the list. You can also type the
   hub's address (the one you open the dashboard at) and press Connect.
Every scene on the hub becomes a key: press to recall. The window shows the hub,
the deck, the scenes (click one to recall it) and the last action. It remembers
the hub for next time.
