# Pyarmor 9.2.3 (pro), 007985, 2025-12-29T22:34:46.328245
from .pyarmor_runtime import __pyarmor__
