# Pyarmor 9.2.3 (pro), 007985, 2025-12-29T22:04:16.676442
from .pyarmor_runtime import __pyarmor__
