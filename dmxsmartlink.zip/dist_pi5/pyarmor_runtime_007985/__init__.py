# Pyarmor 9.2.3 (pro), 007985, 2025-12-29T17:27:21.419132
from .pyarmor_runtime import __pyarmor__
